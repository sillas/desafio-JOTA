STOP_WORDS = set(
    """
a abo ale ani

dokelž

hdyž

jeli jelizo

kaž

pak potom

tež tohodla

zo zoby
""".split()
)
